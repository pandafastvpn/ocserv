/*
 * Copyright (C) 2015 Red Hat, Inc.
 *
 * Author: Nikos Mavrogiannopoulos
 *
 * This file is part of ocserv.
 *
 * ocserv is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 */
#ifndef OC_COMMON_CONFIG_H
#define OC_COMMON_CONFIG_H

#include <config.h>
#include <vpn.h>
#include <ipc.pb-c.h>

char *sanitize_config_value(void *pool, const char *value);
int _add_multi_line_val(void *pool, char ***varname, size_t *num,
			const char *val);
int cfg_parse_ports(void *pool, FwPortSt ***fw_ports, size_t *n_fw_ports,
		    const char *str);

#define MAX_SUBOPTIONS 5

typedef struct subcfg_val_st {
	char *name;
	char *value;
} subcfg_val_st;

typedef struct gssapi_cfg_st {
	char *keytab;
	unsigned int no_local_map;
	time_t ticket_freshness_secs;
	int gid_min;
} gssapi_cfg_st;

typedef struct radius_cfg_st {
	char *config;
	char *nas_identifier;
	/* separator character(s) used in OU= Class attributes */
	const char *group_separator;
} radius_cfg_st;

typedef struct plain_cfg_st {
	char *passwd;
	char *otp_file;
} plain_cfg_st;

typedef struct pam_cfg_st {
	char *service_name;
	int gid_min;
} pam_cfg_st;

#define CHECK_TRUE(str)                                                    \
	((str != NULL &&                                                   \
	  (strcasecmp(str, "true") == 0 || strcasecmp(str, "yes") == 0)) ? \
		 1 :                                                       \
		 0)

struct static_cfg_st;

void *get_brackets_string1(void *pool, const char *str);
void *gssapi_get_brackets_string(void *pool, struct static_cfg_st *config,
				 const char *str);
void *radius_get_brackets_string(void *pool, struct static_cfg_st *config,
				 const char *str);
void *pam_get_brackets_string(void *pool, struct static_cfg_st *config,
			      const char *str);
void *plain_get_brackets_string(void *pool, struct static_cfg_st *config,
				const char *str);
void *oidc_get_brackets_string(void *pool, struct static_cfg_st *config,
			       const char *str);

void parse_kkdcp_string(char *str, int *socktype, char **_port, char **_server,
			char **_path, char **_realm);

#endif
